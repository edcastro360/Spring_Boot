package br.com.aprendizagem.paginaweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginawebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginawebApplication.class, args);
	}

}
