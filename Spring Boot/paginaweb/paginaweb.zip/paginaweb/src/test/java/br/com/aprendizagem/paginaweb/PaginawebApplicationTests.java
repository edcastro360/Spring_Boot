package br.com.aprendizagem.paginaweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginawebApplicationTests {

	@Test
	void contextLoads() {
	}

}
