package com.TDD_JUnit.TDDJUnit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TddjUnitApplicationTests {

	@Test
	void contextLoads() {
	}

}
