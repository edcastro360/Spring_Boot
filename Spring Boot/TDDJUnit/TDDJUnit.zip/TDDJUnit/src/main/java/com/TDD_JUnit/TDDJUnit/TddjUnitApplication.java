package com.TDD_JUnit.TDDJUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TddjUnitApplication {

	public static void main(String[] args) {
		SpringApplication.run(TddjUnitApplication.class, args);
	}

}
