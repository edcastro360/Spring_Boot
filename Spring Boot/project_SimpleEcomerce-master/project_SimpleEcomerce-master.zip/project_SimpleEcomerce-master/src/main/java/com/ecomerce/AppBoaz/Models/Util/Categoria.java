package com.ecomerce.AppBoaz.Models.Util;

public enum Categoria {
	ALIMENTO, VESTUARIO, COSMETICO
}
